package trabajoets;

import java.util.Scanner;

public class CCuenta {

    private String nombre;
    private String cuenta;
    private double saldo;
    private double tipoInteres;

    //constructor por defecto de la clase CCuenta
    public CCuenta() {
    }

    /**
     *
     * @param nombre
     * @param cuenta
     * @param saldo
     * @param tipo
     *
     * Este es el constuctor de la clase cuenta, el cual recibe los parámetros
     * del nombre de la cuenta, el saldo que se le va a introducir por defecto y
     * el tipo, que se refiere al tipo de interés que tendrá la cuenta.
     *
     */
    public CCuenta(String nombre, String cuenta, double saldo, double tipo) {
        this.nombre = nombre;
        this.cuenta = cuenta;
        this.saldo = saldo;
    }

    /**
     *
     * @return
     *
     * Este método es utilizado para devolver el saldo de la cuenta. Se llama
     * estado ya que refleja el estado actual del dinero de la cuenta.
     */
    public double estado() {
        return saldo;
    }

    /**
     *
     * @param cantidad
     * @throws Exception
     *
     * El método ingresar recibe una cantidad que será sumada al saldo de la
     * cuenta,en caso de que no se pueda ya que la cantidad es negativa, saltará
     * un error e informará de ese mismo hecho.
     */
    public void ingresar(double cantidad) throws Exception {
        if (cantidad < 0) {
            throw new Exception("No se puede ingresar una cantidad negativa");
        }
        saldo = saldo + cantidad;
    }

    /**
     *
     * @param cantidad
     * @throws Exception
     *
     * El método retirar recibe una cantidad para restar del saldo de la cuenta.
     * Este método controla tanto que la cantidad a retirar no sea un número
     * negativo, como que el saldo de la cuenta sea el suficiente. En ambos
     * casos, lanzará una excepción con el error pertinente.
     */
    public void retirar(double cantidad) throws Exception {
        if (cantidad <= 0) {
            throw new Exception("No se puede retirar una cantidad negativa");
        }
        if (estado() < cantidad) {
            throw new Exception("No se hay suficiente saldo");
        }
        saldo = saldo - cantidad;
    }

    /**
     *
     * @param cuenta Este método se encarga de gestionar la actividad de la
     * cuenta. Muestra un menú, el cual pregunta al usuario lo que desea hacer.
     *
     * El usuario podrá ver su saldo, ingresar saldo, retirar saldo y salir de
     * la aplicación.
     *
     * En todos los casos se controlan las excepciones que lanzan los métodos
     * {@link retirar} y {@link ingresar}. En cuanto el usuario introduzca una
     * opción no válida, no se permitirá y la aplicación seguirá en marcha
     *
     *
     */
    public void operativa_cuenta(CCuenta cuenta) {
        Scanner sc = new Scanner(System.in);
        double saldoActual;
        boolean salir = false;

        while (!salir) {

            System.out.println("¿Qué deseas hacer?");
            System.out.println("1: mostrar saldo");
            System.out.println("2: agregar saldo");
            System.out.println("3: retirar saldo");
            System.out.println("4: salir");
            int opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    saldoActual = estado();
                    System.out.println("El saldo actual es de " + saldoActual);
                    break;
                case 2:
                try {
                    cuenta.ingresar(695);
                    saldoActual = cuenta.estado();
                    System.out.println("El saldo actual es de" + saldoActual);
                } catch (Exception e) {
                    System.out.print("Fallo al ingresar");
                }
                break;
                case 3:
                try {
                    System.out.println("Ingreso en cuenta");
                    cuenta.retirar(1600);
                    saldoActual = cuenta.estado();
                    System.out.println("El saldo actual es de " + saldoActual);

                } catch (Exception e) {
                    System.out.print("Fallo al retirar");
                }
                break;
                case 4:
                    System.out.println("Gracias por usar la cuenta");
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida");
            }

        }

    }

    //A partir de aquí comienzan los getter y lo setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getTipoInteres() {
        return tipoInteres;
    }

    public void setTipoInteres(double tipoInteres) {
        this.tipoInteres = tipoInteres;
    }

}
